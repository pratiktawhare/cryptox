const mongoose = require('mongoose');
const mongoURI = 'mongodb://localhost:27017/cryptox';

async function run() {
    await mongoose.connect(mongoURI);
    console.log('Connected to MongoDB');

    const User = mongoose.model('User', new mongoose.Schema({ email: String, username: String }));
    const PaperWallet = mongoose.model('PaperWallet', new mongoose.Schema({}, { strict: false }), 'paperwallets');
    const PaperPosition = mongoose.model('PaperPosition', new mongoose.Schema({}, { strict: false }), 'paperpositions');
    const TradeHistory = mongoose.model('TradeHistory', new mongoose.Schema({}, { strict: false }), 'tradehistories');

    const pratik = await User.findOne({ username: 'pratik' });
    if (!pratik) {
        console.log('User pratik not found');
        await mongoose.disconnect();
        return;
    }

    const userId = pratik._id;
    console.log(`Found User ID for pratik: ${userId}`);

    // Cutoff time: June 25, 2026 at 6:00 AM IST (which is 12:30 AM UTC / 00:30 UTC)
    const cutoffDate = new Date('2026-06-25T06:00:00+05:30');
    console.log(`Cutoff date (local): ${cutoffDate.toString()}`);
    console.log(`Cutoff date (ISO): ${cutoffDate.toISOString()}`);

    // 1. Find the trades to delete
    const positionsToDelete = await PaperPosition.find({
        userId,
        status: { $ne: 'open' },
        closedAt: { $lt: cutoffDate }
    });

    console.log(`\nFound ${positionsToDelete.length} paper trades to delete:`);
    let sumPnL = 0;
    let winsToDelete = 0;
    let lossesToDelete = 0;

    positionsToDelete.forEach((p, idx) => {
        sumPnL += p.realisedPnl;
        if (p.realisedPnl >= 0) winsToDelete++;
        else lossesToDelete++;
        console.log(`${idx + 1}. Symbol: ${p.symbol}, PnL: ${p.realisedPnl}, ClosedAt: ${p.closedAt.toISOString()}`);
    });
    console.log(`Total PnL of these trades: ${sumPnL}`);

    if (positionsToDelete.length === 0) {
        console.log('No trades found before the cutoff date.');
        await mongoose.disconnect();
        return;
    }

    // 2. Load current wallet
    const wallet = await PaperWallet.findOne({ userId });
    if (!wallet) {
        console.log('Paper wallet not found');
        await mongoose.disconnect();
        return;
    }

    console.log('\n--- Current Wallet State ---');
    console.log(JSON.stringify(wallet, null, 2));

    // 3. Delete from DB
    const deletePosResult = await PaperPosition.deleteMany({
        userId,
        status: { $ne: 'open' },
        closedAt: { $lt: cutoffDate }
    });
    console.log(`Deleted ${deletePosResult.deletedCount} closed positions.`);

    const deleteHistResult = await TradeHistory.deleteMany({
        userId,
        mode: 'paper',
        $or: [
            { closedAt: { $lt: cutoffDate } },
            { filledAt: { $lt: cutoffDate }, status: { $ne: 'open' } }
        ]
    });
    console.log(`Deleted ${deleteHistResult.deletedCount} trade history records.`);

    // 4. Update paper wallet
    wallet.balance -= sumPnL;
    wallet.equity -= sumPnL;
    wallet.available -= sumPnL;
    wallet.totalRealised -= sumPnL;
    wallet.totalTrades = Math.max(0, (wallet.totalTrades || 0) - positionsToDelete.length);
    wallet.totalWins = Math.max(0, (wallet.totalWins || 0) - winsToDelete);
    wallet.totalLosses = Math.max(0, (wallet.totalLosses || 0) - lossesToDelete);
    
    // Also reset peakEquity if it is lower than equity now
    if (wallet.equity > wallet.peakEquity) {
        wallet.peakEquity = wallet.equity;
    }
    
    await PaperWallet.updateOne({ userId }, {
        $set: {
            balance: wallet.balance,
            equity: wallet.equity,
            available: wallet.available,
            totalRealised: wallet.totalRealised,
            totalTrades: wallet.totalTrades,
            totalWins: wallet.totalWins,
            totalLosses: wallet.totalLosses,
            peakEquity: wallet.peakEquity
        }
    });

    const updatedWallet = await PaperWallet.findOne({ userId });
    console.log('\n--- Updated Wallet State ---');
    console.log(JSON.stringify(updatedWallet, null, 2));

    await mongoose.disconnect();
}

run().catch(console.error);

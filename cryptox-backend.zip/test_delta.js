  const crypto = require('crypto');
const axios = require('axios');

const DELTA_BASE_URL = 'https://api.delta.exchange';

async function testKeys(apiKey, apiSecret) {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const method = 'GET';
    const path = '/v2/wallet/balances';
    const queryString = '';
    const payload = '';
    
    // Delta signature requires: method + timestamp + path + query_string + payload
    const signatureData = method + timestamp + path + queryString + payload;
    const signature = crypto.createHmac('sha256', apiSecret).update(signatureData).digest('hex');

    try {
        const response = await axios.get(`${DELTA_BASE_URL}${path}`, {
            headers: {
                'api-key': apiKey,
                'timestamp': timestamp,
                'signature': signature,
                'User-Agent': 'CryptoX-Agent'
            }
        });
        console.log('Success:', response.data);
    } catch (error) {
        console.error('Error:', error.response?.status, error.response?.data);
    }
}

// Just checking if there's any obvious issue with Delta API.
testKeys('DUMMY', 'DUMMY');
